package routes;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64; // For Base64 encoding if needed for output

public class HmacSha256Generator {

    public static String generateHmacSha256(String message, String secretKey) throws Exception {
        // Create a new Mac instance using HMAC-SHA256
        Mac mac = Mac.getInstance("HmacSHA256");

        // Create a SecretKeySpec from the secret key
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        mac.init(keySpec);

        // Generate the HMAC hash
        byte[] hmacBytes = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));

        // Convert the byte array to a hexadecimal string (common for HMAC output)
        StringBuilder hexString = new StringBuilder();
        for (byte b : hmacBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

     public static String getFormattedTimestamp() 
    {
        long timestamp = System.currentTimeMillis() / 1000L;
        return String.valueOf(timestamp);
}

    public static String genSig() {
        String hmacSignature = "";
        try {
            String secretKey = "Enter secret key here"; // Replace with your actual secret key
            String message = getFormattedTimestamp() + "GET"+"emter path url here";;
            hmacSignature = generateHmacSha256(message, secretKey);
            System.out.println("HMAC-SHA256 Signature (Java): " + hmacSignature);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hmacSignature;
    }
}