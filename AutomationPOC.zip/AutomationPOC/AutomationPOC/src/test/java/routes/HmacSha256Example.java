package routes;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HmacSha256Example {

    

    // Utility: bytes -> hex string
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            // & 0xff to handle negative bytes, +0x100 to ensure at least 3 hex digits, then substring(1)
            sb.append(Integer.toHexString((b & 0xff) + 0x100).substring(1));
        }
        return sb.toString();
    }

    public static String hmacSha256(String secret, String message) throws Exception {
        String algorithm = "HmacSHA256";

        // Create key from the secret
        SecretKeySpec keySpec = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), algorithm);

        // Create Mac instance and init with key
        Mac mac = Mac.getInstance(algorithm);
        mac.init(keySpec);

        // Compute the HMAC on input data bytes
        byte[] rawHmac = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));

        // Return hex-encoded string
        return bytesToHex(rawHmac);
    }

    public static String generateSignature() {
        String signature = "";
        try {
            String secret = "Enter secret key here"; // Replace with your actual secret key
            String signatureString = getFormattedTimestamp() + "GET"+"emter path url here";;

            signature = hmacSha256(signatureString, secret);
            //System.out.println("Message   : " + message);
            //System.out.println("Secret    : " + secret);
            System.out.println("Signature : " + signature);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return signature;
    }

    public static String getFormattedTimestamp() 
    {
        long timestamp = System.currentTimeMillis() / 1000L;
        return String.valueOf(timestamp);
}
}
