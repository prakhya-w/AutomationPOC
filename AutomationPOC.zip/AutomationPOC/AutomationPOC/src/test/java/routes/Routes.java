package routes;

public class Routes {

	public static final String BASE_URL="Enter your base url here";
	

    public static final String GET_APPLICANT=BASE_URL+"Add your endpoint here";
	
   
}
