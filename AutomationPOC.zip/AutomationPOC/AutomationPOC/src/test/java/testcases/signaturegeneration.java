package testcases;

public class signaturegeneration {

    public static void main(String[] args) {
        String signature = routes.HmacSha256Example.generateSignature();
        String timestamp = routes.HmacSha256Example.getFormattedTimestamp();

        System.out.println("Generated Signature: " + signature);
        System.out.println("Timestamp: " + timestamp);
    }

}
