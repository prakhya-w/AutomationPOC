package testcases;

import org.testng.annotations.Test;

import io.restassured.response.ResponseBody;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.lessThanOrEqualTo;
import static org.hamcrest.Matchers.notNullValue;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import routes.HmacSha256Example;
import routes.HmacSha256Generator;
import routes.Routes;

public class getapplicant {

    
        
	    public static void main(String[] args) throws InvalidKeyException, NoSuchAlgorithmException {
            //String secretKey = "Enter secret key"
            //String timestamp = NewSHA256Implementation.getFormattedTimestamp();
            //String signatureString = timestamp + "GET"+"emter path url here";;
            String signature = HmacSha256Generator.genSig();
            String timestamp = HmacSha256Generator.getFormattedTimestamp();
            String apptoken = "Enter your token";

            System.out.println("Generated Signature: " + signature);
            System.out.println("Timestamp: " + timestamp);

	        given()
                .header("X-App-Token", apptoken)
                .header("X-App-Access-Sig", signature)
                .header("X-App-Access-Ts", timestamp)
	            .when()
	                .get(Routes.GET_APPLICANT)
	            .then()
	                //.statusCode(200)
                    .log().all();
	                //.body("size()", greaterThan(0)); // Validate that the response is not empty
	    
        }
}
